$(function(){
	// $(".rilicontent").glDatePicker();
    //ajax获取日历json数据
    // var signList=[{"signDay":"10"},{"signDay":"11"},{"signDay":"12"},{"signDay":"13"}];
    var signList=[];
    var now=new Date;
    var year=now.getFullYear();
    var month=now.getMonth()+1;
    var day=now.getDate();
    $.ajax({
        type : "POST",
        url : "data.json",
        data : {y:year,m:month},
        // timeout : 60000,
        success:function(data){
            calUtil.init(data);
        },
        error:function(){
            console.log("ajax获取初始数据失败！");

        }
    });
    $(".today").click(function(){
        // signList=[{"signDay":day}];
        // calUtil.init(signList);
        $.ajax({
            type : "POST",
            url : "/today.json",
            // data : {data:dataUrl},
            // timeout : 60000,
            success:function(datas){
                var List=datas;
                if(List.status==1){
                    signList=[{"signDay":day}];
                    calUtil.draw(signList);
                }else{
                    alert("您今天已经签到过了!");
                }

            }
        });
        $(".qdsuccess").show();
        // $(".qdsuccess").click(function(){
        // 	$(".qdsuccess").hide();
        // 	$(".yqd").show();
        // 	$(".today").css("color","#bebdbd");
        // })
    });
    $(".qdsuccess").click(function(){
        $(".qdsuccess").hide();
        $(".yqd").show();
        $(".today").css("color","#bebdbd");
    });
});