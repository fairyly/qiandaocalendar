$(function(){
	// $(".rilicontent").glDatePicker();
	
});